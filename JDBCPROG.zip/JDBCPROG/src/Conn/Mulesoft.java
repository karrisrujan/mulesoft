package Conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class Mulesoft {
	 public static void main(String args[])
	  {
		 
		  try {
			  Connection con=null;
			  Class.forName("com.mysql.jdbc.Driver");
			  System.out.println("driver class loaded");
			  con =DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","root");
			  System.out.println("Connection Established");
			  PreparedStatement stm=con.prepareStatement("create database helome");
			  stm.execute();
			  System.out.println("db created");
			  
			  PreparedStatement stm1=con.prepareStatement("use helome");
			  stm1.execute();
			  System.out.println("using db helome");
			  
			  PreparedStatement stm2=con.prepareStatement("create table movie(yearofrelease int primary key, actorname varchar(30) not null, actressname varchar(30) not null, directorname varchar(30) not null)");
			  stm2.execute();
			  System.out.println("movie table created");
			  
			  Scanner sc=new Scanner(System.in);
			  
			  int yr;
			  String actor,actress,dir;
			  for(int i=1;i<=5;i++) {
				  yr=sc.nextInt();
				 actor=sc.next();
			     actress=sc.next();
			     dir=sc.next();
			     PreparedStatement stm3=con.prepareStatement("insert into movie values("+yr+",'"+actor+"','"+actress+"','"+dir+"')");
				 stm3.execute();
			  }
			  System.out.println("values are inserted into table");
			  
			  System.out.println("values in table are");
			  PreparedStatement stm4=con.prepareStatement("select * from movie");
			  ResultSet n=stm4.executeQuery();
			  while (n.next()) {
			        
			        int ID = n.getInt("yearofrelease");
			        String Name1= n.getString("actorname");
			        String Name2 = n.getString("actressname");
			        String Name3 = n.getString("directorname");
			        System.out.println(ID + ", " + Name1 +
			                           ", " + Name2 + ", " + Name3);
			      }
			  
			  System.out.println("select movies based on the actor's name");
			  PreparedStatement stm5=con.prepareStatement("select * from movie where actorname='prabhas'");
			  ResultSet n1=stm5.executeQuery();
			  while (n1.next()) {
			        int ID = n1.getInt("yearofrelease");
			        String Name1= n1.getString("actorname");
			        String Name2 = n1.getString("actressname");
			        String Name3 = n1.getString("directorname");
			        System.out.println(ID + ", " + Name1 +
			                           ", " + Name2 + ", " + Name3);
			      }
		  }
		 
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
	  }
}
